﻿var FHIRrootURL = "https://hapi.fhir.tw/";

//5. FHIR TW with HTTPS  https://hapi.fhir.tw/
// H707 實驗室  http://203.64.84.182:8036/

/* Happy FHIR solution
//http://hapi.fhir.org/baseDstu3
var rootOrgID = "1856069";
//org patient
//http://hapi.fhir.org/baseDstu3/Patient?organization=1856069

//http://hapi.fhir.org/baseDstu3/Organization?partof=1856069
// error http://hapi.fhir.org/baseDstu3/Organization?partOf=1856069

// get patient 1856173 observations
// http://hapi.fhir.org/baseDstu3/Observation?subject=1856173

*/